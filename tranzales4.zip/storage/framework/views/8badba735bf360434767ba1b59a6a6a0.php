<div class="modal fade" id="enviarmodal<?php echo e($doc->id); ?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-scrollable">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalScrollableTitle">Enviar Información al Conductor</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            
            <div id="contenedorC" class="modal-body">
                    <div class="row">
                      
                        <?php $__currentLoopData = json_decode($doc->datos_destinos); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php $__currentLoopData = $destinos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $des): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($des->id==$item): ?>
                                <div class="col-3">
                                    <span class="badge badge-light-primary"><?php echo e($des->referencia); ?></span>
                                    </div> 
                                <?php else: ?>
                                    
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        
                    </div>
                   
            </div>

            <div class="modal-footer">
                
            <a class="btnPdf" id="btnPdf" >pdf</a>
                <input type="hidden" name="id_soli" value="<?php echo e($doc->id); ?>" readonly>
               
                <button type="submit" 
                class="btn btn-success 
                 waves-effect waves-float waves-light" name="enviar" value="enviar">Enviar</button>
              </div>
            
        </div>
    </div>
</div><?php /**PATH C:\xampp\htdocs\tranzales\resources\views/admin/modals/EnviarPlani.blade.php ENDPATH**/ ?>