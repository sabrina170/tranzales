<div class="modal fade" id="edit<?php echo e($doc->id); ?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="exampleModalLabel">Editar Cliente</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close">
            </button>
        </div>
        <div class="modal-body">
          <div class="row">
            <div class="col-md-4 col-12">
                <div class="mb-1">
                    <label class="form-label" for="first-name-column">Nombre</label>
                    <input type="text" id="first-name-column" class="form-control"  name="nombre" value="<?php echo e($doc->nombre); ?>" required>
                </div>
            </div>
            <div class="col-md-4 col-12">
                <div class="mb-1">
                    <label class="form-label" for="first-name-column">Ruc</label>
                    <input type="number" id="ruc" class="form-control"  name="ruc" value="<?php echo e($doc->ruc); ?>" required>
                </div>
            </div>
            <div class="col-md-4 col-12">
              <div class="mb-1">
                  <label class="form-label" for="first-name-column">Referencia</label>
                  <input type="text" id="ruc" class="form-control"  name="referencia" value="<?php echo e($doc->referencia); ?>" required>
              </div>
          </div>
          <div class="col-md-4 col-12">
            <div class="mb-1">
                <label class="form-label" for="last-name-column">Departamento</label>
                <select  class="form-select info-ob" id="departamento" name="departamento"  <?php if(old('departamento')): echo 'selected'; endif; ?>>

                <option value="0">Seleccione un departamento</option>
                    <?php $__currentLoopData = $departamentos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $departamento): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($departamento->id); ?>" <?php if($departamento->id==$doc->id_dep): ?> selected <?php else: ?>  <?php endif; ?>><?php echo e($departamento->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
        </div>
        <div class="col-md-4 col-12">
            <div class="mb-1">
                <label class="form-label" for="city-column">Provincia</label>
                <select  class="form-select info-ob" id="provincia" name="provincia"  <?php if(old('provincia')): echo 'selected'; endif; ?>>

                  <option value="0">Seleccione un departamento</option>
                      <?php $__currentLoopData = $provincias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $prov): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <option value="<?php echo e($prov->id); ?>" <?php if($prov->id==$doc->id_prov): ?> selected <?php else: ?>  <?php endif; ?>><?php echo e($prov->name); ?></option>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </select>
            </div>
        </div>
        <div class="col-md-4 col-12">
            <div class="mb-1">
                <label class="form-label" for="country-floating">Distrito</label>
                <select  class="form-select info-ob" id="distrito" name="providistritoncia"  <?php if(old('distrito')): echo 'selected'; endif; ?>>

                  <option value="0">Seleccione un departamento</option>
                      <?php $__currentLoopData = $distritos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dis): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <option value="<?php echo e($dis->id); ?>" <?php if($dis->id==$doc->id_dis): ?> selected <?php else: ?>  <?php endif; ?>><?php echo e($dis->name); ?></option>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </select>
            </div>
        </div>
          
            <div class="col-md-4 col-12">
                <div class="mb-1">
                    <label class="form-label" for="company-column">Direccion</label>
                    <input type="text" id="direccion" class="form-control" value="<?php echo e($doc->direccion); ?>" required>
                </div>
            </div>
            <div class="col-md-4 col-12">
                <div class="mb-1">
                    <label class="form-label" for="company-column">Tipo de Servicio</label>
                    <select class="form-select" name="tipo_servicio" required>
                      <option value="1" <?php if($doc->tipo_servicio==1): ?> selected <?php else: ?>  <?php endif; ?>>GORRINOS</option>
                      <option value="2" <?php if($doc->tipo_servicio==2): ?> selected <?php else: ?>  <?php endif; ?>>ALIMENTOS</option>
                      <option value="3" <?php if($doc->tipo_servicio==3): ?> selected <?php else: ?>  <?php endif; ?>>LECHONES</option>
                  </select>
                </div>
            </div>
            <div class="col-md-4 col-12">
              <div class="mb-1">
                  <label class="form-label" for="company-column">Estado</label>
                  <select class="form-select" name="estado" required>
                    <option value="1" <?php if($doc->estado==1): ?> selected <?php else: ?>  <?php endif; ?>>Activo</option>
                    <option value="0" <?php if($doc->estado==0): ?> selected <?php else: ?>  <?php endif; ?>>Desactivo</option>
                </select>
              </div>
          </div>
            <div class="col-md-12 col-12">
              <div class="mb-1">
                  <label class="form-label" for="company-column">Contactos</label>
              </div>
              
            </div> 
            
          </div>
          <div class="container text-center">
            <div class="row ">
              <div class="col badge badge-light-dark">CONTACTO</div>
              <div class="col badge badge-light-dark">TELEFONO</div>
              <div class="col badge badge-light-dark">CARGO</div>
              <div class="col badge badge-light-dark">CORREO</div>
            </div>
          </div>
          <div class="container text-center">
              <?php $__currentLoopData = json_decode($doc->contactos); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <div class="row">
                <div class="col-3"><?php echo e($item->contacto); ?></div>
                <div class="col-3"><?php echo e($item->telefono); ?></div>
                <div class="col-3"><?php echo e($item->cargo); ?></div>
                <div class="col-3"><?php echo e($item->correo); ?></div>
              </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </div>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cerrar</button>
        </div>
      </div>
    </div>
  </div>
  <?php /**PATH C:\xampp\htdocs\tranzales\resources\views/admin/modals/modaledicli.blade.php ENDPATH**/ ?>