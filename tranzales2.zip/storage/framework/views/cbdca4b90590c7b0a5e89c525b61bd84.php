

<!-- MENU -->
<?php $__env->startSection('content'); ?>

<div class="content-header row">
    <div class="content-header-left col-md-9 col-12 mb-2">
        <div class="row breadcrumbs-top">
            <div class="col-12">
                <h2 class="content-header-title float-start mb-0">Modulo</h2>
                <div class="breadcrumb-wrapper">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="index.html">Solicitudes</a>
                        </li>
                        <li class="breadcrumb-item active">Detalle
                        </li>
                    </ol>
                </div>
            </div>
        </div>
    </div>
    
    <div class="content-header-left text-md-end col-md-3 col-12 d-md-block d-none">
        <div class="mb-1 breadcrumb-left">
            <a href="<?php echo e(route('admin.solicitudes.nueva-solicitud')); ?>" type="button" class="btn btn-danger waves-effect waves-float waves-light">Agregar +</a>
        </div>
    </div>
</div>


<div class="content-body">
    <!-- Basic Tables start -->
    <div class="row" id="basic-table">
        <div class="col-12">
            <div class="card">
             
                <div class="card-body">
                    
                </div>
                <div class="table-responsive">
                    <table class="table table-sm">
                        <thead>
                            <tr>
                                
                                <th>CODIGO SOLICITUD</th>
                                <th>FECHA SOLICITUD</th>
                                <th>CLIENTE</th>
                                <th>FECHA TRASLADO</th>
                                <th>HORA</th>
                                <th>CANTIDAD</th>
                                <th>COSTO</th>
                                <th>ESTADO</th>
                                <th>UNIDAD/CHOFER <br>/AYUDANTE</th>
                                <th>Indidencia finales</th>
                                
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $solicitudes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $doc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr> 
                                <td><?php echo e($doc->codigo_solicitud); ?></td>
                                <td><?php echo e($doc->fecha_solicitud); ?></td>
                                <td><?php echo e($doc->cliente); ?></td>
                                <td><?php echo e($doc->fecha_traslado); ?></td>
                                
                                <td><?php echo e($doc->hora); ?></td>
                                <td><?php echo e($doc->cantidad); ?></td>
                                <td><?php echo e($doc->costo); ?></td>
                                <td>
                                    <?php if($doc->estado==1): ?>
                                    <span class="badge bg-warning">Pendiente</span>
                                    <?php else: ?>
                                    <span class="badge bg-success">Entregada</span>
                                    <?php endif; ?></td>
                                    <td><button type="button" class="btn btn-outline-primary waves-effect"
                                         data-bs-toggle="modal" data-bs-target="#crearmodal<?php echo e($doc->id); ?>">
                                        Asignar
                                    </button></td>
                                    <td>
                                        <?php if($doc->estado==2): ?> 
                                        <button type="button" class="btn btn-outline-primary waves-effect"
                                         data-bs-toggle="modal" data-bs-target="#exampleModalScrollable">
                                            Asignar
                                        </button>
                                        <?php else: ?>
                                        <button type="button" class="btn btn-outline-primary waves-effect" 
                                        data-bs-toggle="modal" data-bs-target="#exampleModalScrollable" disabled>
                                            Asignar
                                        </button>
                                        <?php endif; ?>
                                    </td>
                                
                            </tr>
                            <?php echo $__env->make('admin.modals.CrearPlani', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
    <!-- Basic Tables end -->

   

</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>

  <script>
    var idioma=

{
    "sProcessing":     "Procesando...",
    "sLengthMenu":     "Mostrar _MENU_ registros",
    "sZeroRecords":    "No se encontraron resultados",
    "sEmptyTable":     "NingÃºn dato disponible en esta tabla",
    "sInfo":           "Mostrando registros del _START_ al _END_ de un total de _TOTAL_ registros",
    "sInfoEmpty":      "Mostrando registros del 0 al 0 de un total de 0 registros",
    "sInfoFiltered":   "(filtrado de un total de _MAX_ registros)",
    "sInfoPostFix":    "",
    "sSearch":         "Buscar:",
    "sUrl":            "",
    "sInfoThousands":  ",",
    "sLoadingRecords": "Cargando...",
    "oPaginate": {
        "sFirst":    "Primero",
        "sLast":     "Ãšltimo",
        "sNext":     "Siguiente",
        "sPrevious": "Anterior"
    },
    "oAria": {
        "sSortAscending":  ": Activar para ordenar la columna de manera ascendente",
        "sSortDescending": ": Activar para ordenar la columna de manera descendente"
    },
    "buttons": {
        "copyTitle": 'Informacion copiada',
        "copyKeys": 'Use your keyboard or menu to select the copy command',
        "copySuccess": {
            "_": '%d filas copiadas al portapapeles',
            "1": '1 fila copiada al portapapeles'
        },

        "pageLength": {
        "_": "Mostrar %d filas",
        "-1": "Mostrar Todo"
        }
    }
};

$(document).ready( function () {
   var table = $('#colegios').DataTable({
    dom: 'Blfrtip',
    // "dom": 'Br<"float-left"i><"float-right"f>t<"float-left"l><"float-right"p><"clearfix">',
    // "lengthMenu": [[5,10,20, -1],[5,10,50,"Mostrar Todo"]],
    // "dom": 'Bfrt<"col-md-6 inline"i> <"col-md-6 inline"p>',
    language: idioma,
    buttons: [
        'excel'
    ],
    exportOptions: {
        modifier: {
          // DataTables core
          order: 'index', // 'current', 'applied',
          //'index', 'original'
          page: 'all', // 'all', 'current'
          search: 'none' // 'none', 'applied', 'removed'
        },
    
            columns: [1, 2, 3, 4, 5, 6, 7,8,9]
      
      }
   });

} );

$('#unidad').on('change', function(){
       
       var id = $(this).val();
       // alert(id);
       // alert(id);
           $.ajax({
           url:'<?php echo e(route('buscarunidad')); ?>',
           type:'GET',
           data:{'id':id},
           dataType:'json',
           success:function (data) {
               console.log(data);
               // $('#product_list').html(data);
               $('#datos_unidad').val(data);
               // alert(data.table_data);
           }
       })
   });

   $('#chofer').on('change', function(){

var id = $(this).val();
// alert(id);
// alert(id);
  $.ajax({
  url:'<?php echo e(route('buscarchofer')); ?>',
  type:'GET',
  data:{'id':id},
  dataType:'json',
  success:function (data) {
      console.log(data);
      // $('#product_list').html(data);
      $('#datos_chofer').val(data);
      // alert(data.table_data);
  }
})
});
</script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\tranzales\resources\views/admin/solicitudes/index.blade.php ENDPATH**/ ?>