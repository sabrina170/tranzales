<div class="modal fade" id="crearmodal<?php echo e($doc->id); ?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-scrollable modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalScrollableTitle">Modal title</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <?php if($doc->estado==2): ?>
                
            <?php else: ?>
            <form action="<?php echo e(route('crear-plani')); ?>" method="post" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
            <div class="modal-body">
                    <div class="row">
                        <!-- Basic -->
                        <div class="col-md-6 mb-1">
                            <label class="form-label" for="select2-basic">Unidad</label>
                            <select class="form-select" id="unidad" name="unidad">
                                <?php $__currentLoopData = $vehiculos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $doc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($doc->id); ?>"> <?php echo e($doc->unidad); ?></option>
                               
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>   
                             </select>   
                        </div>
                        <div class="col-md-6 mb-1">
                            <label class="form-label" for="basicInput">Datos de la unidad</label>
                            <input type="text" class="form-control" id="datos_unidad"  readonly>
                        </div>
                        
                        <div class="col-md-6 mb-1">
                            <label class="form-label" for="select2-basic">Chofer</label>
                            <select class="select2 form-select" id="chofer" name="chofer">
                                <?php $__currentLoopData = $choferes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $doc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($doc->id); ?>"> <?php echo e($doc->dni_cho); ?></option>
                               
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>   
                            </select>   
                        </div>
                        <div class="col-md-6 mb-1">
                            <label class="form-label" for="basicInput">Nombres y Apellido</label>
                            <input type="text" class="form-control" id="datos_chofer" readonly>
                        </div>
                        
                        <div class="col-md-6 mb-1">
                            <label class="form-label" for="select2-basic">Ayudantes</label>
                            <select class="select2 form-select" id="select2-multiple" multiple name="ayudantes[]">
                          
                                <?php $__currentLoopData = $choferes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $doc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($doc->id); ?>"> <?php echo e($doc->nombres_cho); ?>- <?php echo e($doc->dni_cho); ?></option>
                               
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>   
                            </select>
                        </div>
                    </div>
            </div>

            <div class="modal-footer">
                <button type="submit" type="Guardar" class="btn btn-primary waves-effect waves-float waves-light">Guardar</button>
                
            </div>
            <?php endif; ?>
            
        </div>
    </div>
</div><?php /**PATH C:\xampp\htdocs\tranzales\resources\views/admin/modals/CrearPlani.blade.php ENDPATH**/ ?>